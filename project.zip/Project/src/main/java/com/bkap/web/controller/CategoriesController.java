package com.bkap.web.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bkap.web.entity.Category;
import com.bkap.web.repository.CategoryRepository;

/**
 * Servlet implementation class CategoriesController
 */
@WebServlet({ "/CategoriesController", "/home", "/danh-muc" })
public class CategoriesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private CategoryRepository categoryRepositoty;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CategoriesController() {
       categoryRepositoty = new CategoryRepository();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String view = "";
		
		String action = request.getParameter("action");
		
		
		if (action == null || action.equals("index")) {
			List<Category> data = categoryRepositoty.getAll();
			request.setAttribute("list", data);
			view = "views/categories/index.jsp";
		} else if (action.equals("add")) {
			view = "views/categories/insert.jsp";
		} else if (action.equals("edit")) {
			String id = request.getParameter("id");
			request.setAttribute("cat", categoryRepositoty.findId(Integer.parseInt(id)));
			view = "views/categories/update.jsp";
		} else if (action.equals("delete")) {
			String id = request.getParameter("id");
			categoryRepositoty.remove(Integer.parseInt(id));
			List<Category> data = categoryRepositoty.getAll();
			request.setAttribute("list", data);
			view = "views/categories/index.jsp";
		} else {
			view = "views/not-found.jsp";
		}
		request.getRequestDispatcher(view).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
