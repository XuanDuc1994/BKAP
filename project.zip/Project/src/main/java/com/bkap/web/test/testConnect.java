package com.bkap.web.test;

import java.sql.Connection;
import java.sql.DriverManager;

import com.bkap.web.repository.CategoryRepository;
import com.bkap.web.util.SqlConnection;

public class testConnect {
	public static Connection open() {
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			return DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Travel_Management", "sa",
					"12345");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
			
		}
		
	}
public static void main(String[] args) {
	Connection sc = open();
	if(sc!=null) {
		System.out.println("ok");
	} else {
		System.out.println("erro");
	}
}
}
