package com.bkap.web.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SqlConnection {
	public static Connection open() {
		try {

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			return DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Travel_Management", "sa",
					"12345");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
			
		}
		
	}
public static void main(String[] args) {
	Connection sc = open();
	if(sc!=null) {
		System.out.println("ok");
	} else {
		System.out.println("erro");
	}
}
	public static ResultSet excute(String sql, Object... params) throws SQLException {
		// B1: Tạo kết nối
		Connection conn = SqlConnection.open();
		// B2: Tạo đối tượng thực thi câu truy
		PreparedStatement ps = conn.prepareStatement(sql);
		// B2.1: Truyền tham số nếu có
		if (params != null) {
			for (int i = 0; i < params.length; i++) {
				ps.setObject(i + 1, params[i]);
			}
		}
		// B3: Thực thi truy vấn
		ResultSet rs = ps.executeQuery();
		return rs;
	}

	public static int update(String sql, Object... params) throws SQLException {
		// B1: Tạo kết nối
		Connection conn = SqlConnection.open();
		// B2: Tạo đối tượng thực thi câu truy
		PreparedStatement ps = conn.prepareStatement(sql);
		// B2.1: Truyền tham số nếu có
		if (params != null) {
			for (int i = 0; i < params.length; i++) {
				ps.setObject(i + 1, params[i]);
			}
		}
		// B3: Thực thi truy vấn
		return ps.executeUpdate();
	}
}
